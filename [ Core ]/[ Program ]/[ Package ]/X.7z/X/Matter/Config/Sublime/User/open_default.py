import os
import subprocess
import sublime
import sublime_plugin

class OpenDefault(sublime_plugin.WindowCommand):
	def run(self, files):
		for f in files:
			os.startfile(f)
			#subprocess.run(["C:\\Program Files\\Notepad++\\notepad++.exe", f])
			#subprocess.Popen(["C:\\Program Files\\Notepad++\\notepad++.exe", f], start_new_session=True)
