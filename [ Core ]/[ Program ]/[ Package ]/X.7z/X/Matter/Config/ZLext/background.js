let color = '#3aa757';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ color });
  console.log('Default background color set to %cgreen', `color: ${color}`);
});

// CSP
let isCSPDisabled = false

const onHeadersReceived = function(details) {
  if (!isCSPDisabled) return

  for (let i = 0; i < details.responseHeaders.length; i++)
    if (details.responseHeaders[i].name.toLowerCase() === "content-security-policy")
      details.responseHeaders[i].value = ""

  return {
    responseHeaders: details.responseHeaders,
  }
}

const filter = {
  urls: ["*://*/*"],
  types: ["main_frame", "sub_frame"],
}

chrome.webRequest.onHeadersReceived.addListener(onHeadersReceived, filter, [
  "blocking",
  "responseHeaders",
])
