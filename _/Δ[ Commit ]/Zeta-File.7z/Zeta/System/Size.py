from tkinter import *

class Screen():
	def __init__(self):
		self.width = 1366
		self.height = 768

class Window():
	def __init__(self):
		self.main = [920, 740]
		self.side = [444, 740]
		self.mpv = [444, 270]
		self.npp = [444, 424]
		self.aimp = [444, 50]