import Zeta


class Panel():
    def __init__(self):
        self.antifragment = True
        self.antiflicker = False

class Editor():
    def __init__(self):
        pass

class Browser():
    def __init__(self):
        pass

class OS():
    def __init__(self):
        pass