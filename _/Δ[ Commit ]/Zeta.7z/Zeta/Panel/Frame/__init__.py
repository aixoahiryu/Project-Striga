from .Corner import CornerFrame
from .Gradient import GradientFrame
from .Mono import MonoFrame